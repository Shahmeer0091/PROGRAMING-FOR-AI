import cv2
import torch
import numpy as np
from ultralytics import YOLO
from deep_sort_realtime.deepsort_tracker import DeepSort
import requests

# Load YOLOv8 model
model = YOLO('yolov8n.pt')  # You can use a custom-trained model

# Initialize DeepSORT for tracking
tracker = DeepSort(max_age=30, n_init=2, nn_budget=100)

# Google Maps API setup
GOOGLE_MAPS_API_KEY = "YOUR_GOOGLE_MAPS_API_KEY"
ALERT_THRESHOLD = 5  # Min number of animals in a herd

# Open webcam
cap = cv2.VideoCapture(0)

def send_alert(latitude, longitude):
    url = f"https://maps.googleapis.com/maps/api/staticmap?center={latitude},{longitude}&zoom=15&size=600x300&maptype=roadmap&key={GOOGLE_MAPS_API_KEY}"
    print(f"ALERT: Herd detected! Location: {latitude}, {longitude}")
    print(f"Google Maps Link: {url}")

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    results = model(frame)
    detections = []

    for result in results:
        for box in result.boxes.xyxy:  # Get bounding box
            x1, y1, x2, y2 = map(int, box[:4])
            conf = float(result.boxes.conf[0])
            class_id = int(result.boxes.cls[0])
            
            # Consider only animals (adjust class IDs as needed)
            if class_id in [15, 16, 17, 18]:  # Example IDs for animals
                detections.append(([x1, y1, x2, y2], conf, class_id))
    
    # Track objects
    tracked_objects = tracker.update_tracks(detections, frame=frame)
    herd_count = 0
    
    for track in tracked_objects:
        if not track.is_confirmed():
            continue
        track_id = track.track_id
        x1, y1, x2, y2 = map(int, track.to_tlbr())
        
        # Draw bounding boxes and track ID
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.putText(frame, f"ID: {track_id}", (x1, y1 - 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
        herd_count += 1
    
    # If herd detected, send alert with dummy GPS
    if herd_count >= ALERT_THRESHOLD:
        send_alert(37.7749, -122.4194)  # Example coordinates (San Francisco)
    
    # Show frame
    cv2.imshow("Animal Herd Detection", frame)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
